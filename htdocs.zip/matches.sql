-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u2
-- http://www.phpmyadmin.net
--
-- Machine: localhost
-- Gegenereerd op: 06 nov 2016 om 17:13
-- Serverversie: 5.5.52-0+deb8u1
-- PHP-versie: 5.6.27-0+deb8u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Databank: `MATCHES`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `CurrentGame`
--

CREATE TABLE IF NOT EXISTS `CurrentGame` (
`ID` mediumint(9) NOT NULL,
  `GameID` int(10) unsigned DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `CurrentGame`
--

INSERT INTO `CurrentGame` (`ID`, `GameID`) VALUES
(1, 20);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `games`
--

CREATE TABLE IF NOT EXISTS `games` (
`ID` mediumint(9) NOT NULL,
  `Team1` int(11) DEFAULT NULL,
  `Team2` int(11) DEFAULT NULL,
  `PuntTeam1` int(11) unsigned DEFAULT NULL,
  `PuntTeam2` int(11) unsigned DEFAULT NULL,
  `StartTime` int(11) DEFAULT NULL,
  `EndTime` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

--
-- Gegevens worden geëxporteerd voor tabel `games`
--

INSERT INTO `games` (`ID`, `Team1`, `Team2`, `PuntTeam1`, `PuntTeam2`, `StartTime`, `EndTime`) VALUES
(1, 1, 2, 0, 2, 51901, 52204),
(2, 3, 4, 3, 0, 52434, 52739),
(3, 5, 1, 0, 3, 52979, 53286),
(4, 2, 3, 0, 0, 53367, 53669),
(5, 4, 5, 1, 0, 53899, 54174),
(6, 1, 3, 0, 2, 54382, 54686),
(7, 5, 2, 1, 0, 54801, 55103),
(8, 4, 1, 1, 0, 55241, 55542),
(9, 3, 5, 0, 0, 55736, 56037),
(10, 2, 4, 0, 0, 56147, 56448),
(11, 6, 7, 1, 0, 57753, 57966),
(12, 8, 9, 0, 0, 58053, 58363),
(13, 10, 6, 0, 0, 58470, 58772),
(14, 7, 8, 0, 0, 58885, 59187),
(15, 9, 10, 1, 0, 59314, 59618),
(16, 6, 8, 0, 0, 59725, 60027),
(17, 10, 7, 0, 0, 60102, 60404),
(18, 9, 6, 0, 0, 60473, 60774),
(19, 8, 10, 2, 0, 60896, 61198),
(20, 7, 9, 0, 0, 61281, 61583);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `teams`
--

CREATE TABLE IF NOT EXISTS `teams` (
`ID` mediumint(9) NOT NULL,
  `team` varchar(12) DEFAULT NULL,
  `poule` varchar(1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `teams`
--

INSERT INTO `teams` (`ID`, `team`, `poule`) VALUES
(1, 'WIT The Wave', 'A'),
(2, 'ZWT OWB', 'A'),
(3, 'GRN Team HLM', 'A'),
(4, 'RD Team Adam', 'A'),
(5, 'RZ Steph Ang', 'A'),
(6, 'WIT Palmare', 'B'),
(7, 'ZWT Sub 70', 'B'),
(8, 'GRN Nekton', 'B'),
(9, 'RD De Guppen', 'B'),
(10, 'RZ Archimed', 'B');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `CurrentGame`
--
ALTER TABLE `CurrentGame`
 ADD PRIMARY KEY (`ID`);

--
-- Indexen voor tabel `games`
--
ALTER TABLE `games`
 ADD PRIMARY KEY (`ID`);

--
-- Indexen voor tabel `teams`
--
ALTER TABLE `teams`
 ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `CurrentGame`
--
ALTER TABLE `CurrentGame`
MODIFY `ID` mediumint(9) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT voor een tabel `games`
--
ALTER TABLE `games`
MODIFY `ID` mediumint(9) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT voor een tabel `teams`
--
ALTER TABLE `teams`
MODIFY `ID` mediumint(9) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
