<!---------------------------------------------------------------------------
Example client script for JQUERY:AJAX -> PHP:MYSQL example
meta http-equiv="refresh" content="2"
sensordata tables
---------------------------------------------------------------------------->

<html>
  <head>
    <script language="javascript" type="text/javascript" src="../jquery.js"></script>

  </head>
  <body>

  <!-------------------------------------------------------------------------
  1) Create some html content that can be accessed by jquery
  -------------------------------------------------------------------------->

  <div id="output" ><h2><font color=white>This element will be accessed by jquery and this text replaced </h2> </div>

  <script id="source" language="javascript" type="text/javascript">

  setInterval(function ()
  {
    //-----------------------------------------------------------------------
    // 2) Send a http request with AJAX http://api.jquery.com/jQuery.ajax/
    //-----------------------------------------------------------------------
    $.ajax({
      url: 'matchSQL.php',                  //the script to call to get data
      data: "",                        //you can insert url argumnets here to pass to api.php
                                       //for example "id=5&parent=6"
      dataType: 'json',                //data format
      success: function(data)          //on recieve of reply
      {
        var vteam1 = data[0];              //get id
        var vteam2 = data[1];           //get name
        var vpuntteam1 = data[2];
        var vpuntteam2 = data[3];
        var MatchID = data[4];
        var Timer =  data[5]      // php in html X sprintf('%02d-%02d', data[5], data[6]);

        //--------------------------------------------------------------------
        // 3) Update html content
        //--------------------------------------------------------------------
        $('#output').html("<h1> <font color=white  size=7> <center>" + Timer + "<BR>" + "Match: " +  MatchID + "<br>" +
         vteam1 +" tegen " + vteam2 +"<br>"
        + vpuntteam1 + " - " + vpuntteam2 + "<br>"
	+   " </center> </font> </h1>" ); //Set output element html
        //recommend reading up on jquery selectors they are awesome
        // http://api.jquery.com/category/selectors/
      }
    });
  },1000);

  </script>
  </body>
</html>


