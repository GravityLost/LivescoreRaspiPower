<?php
$mysqli = new mysqli("localhost", "root", "ROVsqlzone", "MATCHES");
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}

$sql = "UPDATE games set games.StartTime='0' WHERE games.ID = (SELECT max( CurrentGame.GameID) FROM CurrentGame);";
$sql.= "UPDATE games set games.EndTime='0' WHERE games.ID = (SELECT max( CurrentGame.GameID) FROM CurrentGame);";

if (!$mysqli->multi_query($sql)) {
    echo "Multi query failed: (" . $mysqli->errno . ") " . $mysqli->error;
}
echo "<a href=\"javascript:history.go(-1)\">GO BACK</a>";
?>