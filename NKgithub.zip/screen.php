    <html>
<title>NK onderwatervoetbal</title>
      <head>
<style>
h1 {
    font-size: 20px;
    font-color: white;
}


body {
    background-color: grey;
    font-color: white;
}
</style>







    <head>
        <title>UV4L Stream</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <script>
            function errorFunction() {
                alert('Stream stopped');
            }
        </script>
        <img src="http://RASPBERRY3A:9090/stream/video.mjpeg" alt="Live feed. If this video is not starting check if UV4L has been executed on Raspberry.
        Maybe the IP address pointing to the source of the stream is not correct."  >
    </body>



 <div id="current-match" style="position:absolute; top: 0px; left: 00px; size: 7;">
  <p><iframe src="./screen/match.php" frameborder="0" height="1200" scrolling="no"
      width="1000" scrolling="no"></iframe></p>
</div>

 <div id="list-of-teams" style="position:absolute; top: 0px; left: 1000px; ">
  <p><iframe src="./screen/teamslistSQL.php" frameborder="0" height="400" scrolling="no"
      width="400"></iframe></p>
</div>

 <div id="sorted-by-points" style="position:absolute; top: 500px; left: 1000px; ">
  <p><iframe src="./screen/resultlistSQL.php" frameborder="0" height="400" scrolling="no"
      width="400"></iframe></p>
</div>


 <div id="list-of-all-matches-points" style="position:absolute; top: 0px; left: 1400px; ">
  <p><iframe src="./screen/matcheslistSQL.php" frameborder="0" height="1200" scrolling="no"
      width="500"></iframe></p>
</div>


<?php
// PHP section

// set some variables
// Image directory! fill in! relative to root
$imageDir = './screen/sponsors/';
define('SERVERPATH', $_SERVER['DOCUMENT_ROOT'].$imageDir);
define('HTTPPATH', 'http://'.$_SERVER['HTTP_HOST'].$imageDir);

// read the names of images from the image directory
$dir = opendir(SERVERPATH);
$javascriptArray = null;
$i = null;
while (false !== ($file = readdir($dir))) {
	if (eregi('\\.(gif|png|jpg)$', $file)){
	    $javascriptArray .= $i.'"'.HTTPPATH.$file.'"';
	    $i = ',';
	}
}
closedir($dir);

// Html section
?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
"http://www.w3.org/TR/html4/strict.dtd">

<html lang="en">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">

		<script type="text/javascript">
			rotatingImages = new Array(<?php echo $javascriptArray; ?>);
			imageCount = rotatingImages.length;
			firstTime = true;
			duration = "10"; //seconds

			function rotateImage(){
				// Cycle through images sequencially starting with a random image
				// Do not update the image if loading is not yet completed
				if (document.getElementById('rotatingImage').complete || firstTime){
					if (firstTime) {
						thisImage = Math.floor((Math.random() * imageCount))
						firstTime = false
					}else{
						thisImage++
						if (thisImage == imageCount) {
							thisImage = 0
						}
					}
					document.getElementById('rotatingImage').src = rotatingImages[thisImage]
					setTimeout("rotateImage()", duration * 1000)
				}
			}
		</script>
		<style type="text/css">
			#slideshow{
                position:absolute;
                top: 350px;
                left: 10px
                width:200px;
				height:200px;

			}

			#rotatingImage{
				display:block;
                position:absolute;
                top: 300px;
                left: 10px
				width:200px;
				height:200px;

			}
		</style>
	</head>
	<body>
		<div id="slideshow">
			<img id="rotatingImage" src="" alt="">
		</div>
		<script type="text/javascript">
			rotateImage();
		</script>
	</body>
</html>