

<?php
    if (isset($_POST['prevmatch']))
    {
         exec('mysql -uUSER1 -pNKtest MATCHES -e "UPDATE CurrentGame SET CurrentGame.GameID = CurrentGame.GameID - 1";');
    }
        if (isset($_POST['nextmatch']))
    {
         exec('mysql -uUSER1 -pNKtest MATCHES -e "UPDATE CurrentGame SET CurrentGame.GameID = CurrentGame.GameID + 1";');
    }
        if (isset($_POST['T1P1']))
    {
         exec('mysql -uUSER1 -pNKtest MATCHES -e "UPDATE games set games.PuntTeam1=games.PuntTeam1+1 WHERE games.ID = (SELECT max( CurrentGame.GameID) FROM CurrentGame)";');
    }
        if (isset($_POST['T1-P1']))
    {
         exec('mysql -uUSER1 -pNKtest MATCHES -e "UPDATE games set games.PuntTeam1=games.PuntTeam1-1 WHERE games.ID = (SELECT max( CurrentGame.GameID) FROM CurrentGame)";');
    }
            if (isset($_POST['T2P1']))
    {
         exec('mysql -uUSER1 -pNKtest MATCHES -e "UPDATE games set games.PuntTeam2=games.PuntTeam2+1 WHERE games.ID = (SELECT max( CurrentGame.GameID) FROM CurrentGame)";');
    }
        if (isset($_POST['T2-P1']))
    {
         exec('mysql -uUSER1 -pNKtest MATCHES -e "UPDATE games set games.PuntTeam2=games.PuntTeam2-1 WHERE games.ID = (SELECT max( CurrentGame.GameID) FROM CurrentGame)";');
    }
     if (isset($_POST['left']))
    {
         exec('echo 17=0.20 > /dev/pi-blaster');
    }
     if (isset($_POST['midl']))
    {
         exec('echo 17=0.17 > /dev/pi-blaster');
    }
     if (isset($_POST['right']))
    {
         exec('echo 17=0.13 > /dev/pi-blaster');
    }
         if (isset($_POST['T-start']))
    {
         exec('mysql -uUSER1 -pNKtest MATCHES -e "UPDATE games set games.StartTime=(if(games.StartTime=0,hour(now())*3600+minute(now())*60+second(now()),games.StartTime)) WHERE games.ID = (SELECT max( CurrentGame.GameID) FROM CurrentGame)";');
    }
         if (isset($_POST['T-stop']))
    {
         exec('mysql -uUSER1 -pNKtest MATCHES -e "UPDATE games set games.EndTime=(if(games.EndTime=0,hour(now())*3600+minute(now())*60+second(now()),games.EndTime)) WHERE games.ID = (SELECT max( CurrentGame.GameID) FROM CurrentGame)";');
    }
         if (isset($_POST['T-reset']))
    {
         exec('mysql -uUSER1 -pNKtest MATCHES -e "UPDATE games set games.StartTime= 0  WHERE games.ID = (SELECT max( CurrentGame.GameID) FROM CurrentGame); UPDATE games set games.EndTime = 0 WHERE games.ID = (SELECT max( CurrentGame.GameID) FROM CurrentGame)";');
    }
             if (isset($_POST['T-herstart']))
    {
         exec('mysql -uUSER1 -pNKtest MATCHES -e "UPDATE games set games.StartTime=hour(now())*3600+minute(now())*60+second(now())+games.StartTime-games.EndTime WHERE games.ID = (SELECT max( CurrentGame.GameID) FROM CurrentGame);UPDATE games set games.EndTime= 0 WHERE games.ID = (SELECT max( CurrentGame.GameID) FROM CurrentGame)";');
    }
?>
<html>
<style>
.myButtonG {
                    background-color:#44c767;
                    -moz-border-radius:50px;
                    -webkit-border-radius:50px;
                    border-radius:20px;
                    border:5px solid #18ab29;
                    display:inline-block;
                    cursor:pointer;
                    color:#ffffff;
                    font-family:Arial;
                    font-size:60px;
                    padding:30px 30px;
                    text-decoration:none;
                    text-shadow:0px 1px 0px #2f6627;
                    width:400px; }
.myButtonR {
                    background-color:#f44336;
                    -moz-border-radius:50px;
                    -webkit-border-radius:50px;
                    border-radius:20px;
                    border:5px solid #18ab29;
                    display:inline-block;
                    cursor:pointer;
                    color:#ffffff;
                    font-family:Arial;
                    font-size:60px;
                    padding:30px 30px;
                    text-decoration:none;
                    text-shadow:0px 1px 0px #2f6627;
                    width:400px; }
.myButtonsmall {
                    background-color:#f44336;
                    -moz-border-radius:50px;
                    -webkit-border-radius:50px;
                    border-radius:20px;
                    border:5px solid #18ab29;
                    display:inline-block;
                    cursor:pointer;
                    color:#ffffff;
                    font-family:Arial;
                    font-size:40px;
                    padding:30px 30px;
                    text-decoration:none;
                    text-shadow:0px 1px 0px #2f6627;
                    width:265px; }

.myButton:hover {
                    background-color:#5cbf2a;
}
.myButton:active {
                    position:relative;
                    top:1px;
}
body {
    background-color: black;
    font-color: white;
}
h1 {
    font-size: 400px;
}
</style>

<body>
    <form method="post">

        <button class="myButtonR" name="prevmatch">prevmatch</button>
        <button class="myButtonG" name="nextmatch">nextmatch</button> <BR> <BR>
        <button class="myButtonG" name="T1P1">Team1 +1</button>
        <button class="myButtonG" name="T2P1">Team2 +1</button> <BR> <BR>
        <button class="myButtonsmall" name="T-start">Start   time</button>
        <button class="myButtonsmall" name="T-stop">Stop   time</button>
        <button class="myButtonsmall" name="T-herstart">Herstart  time</button> <BR><BR>

        <button class="myButtonsmall" name="left">Cam - links</button>
        <button class="myButtonsmall" name="midl">Cam - middel</button>
        <button class="myButtonsmall" name="right">Cam - rechts</button> <BR>
        <BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR><BR>
        <button class="myButtonsmall" name="T-reset">Reset Time</button> <BR> <BR>
        <button class="myButtonR" name="T1-P1">Team1 -1</button>
        <button class="myButtonR" name="T2-P1">Team2 -1</button> <BR>

    </form>


 <div id="list1" style="position:absolute; top: 700px; left: 0px; size: 7; ">
  <p><iframe src="./controlscore/match.php" frameborder="0" height="250" scrolling="no"
      width="280%"></iframe></p>
</div>





</body>
</html>