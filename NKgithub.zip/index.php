<html>
<style>
a:link {
    font-size:50px
    }
    </style>
    <body>
<h1>Raspberry camera A</h1>
<a href="controlscore.php">Score controlboard</a> <BR>
<a href="screen.php">Screen with live view and lists</a> <BR>
<a href="/phpmyadmin">Ga naar SQL management</a> <BR>
<BR>
<a href="./index/T-start.php">start time</a> <BR>
<a href="./index/T-stop.php">stop time</a> <BR>
<a href="./index/T-herstart.php">restart time</a> <BR>

<a href="./index/T-reset.php">reset time</a> <BR>

(/body>
</html>