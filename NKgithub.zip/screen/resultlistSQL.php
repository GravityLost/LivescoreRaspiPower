<?php
$servername = "localhost";
$username = "USER1";
$password = "NKtest";
$dbname = "MATCHES";

if (!mysql_connect($servername, $username, $password))
    die("Can't connect to database");

if (!mysql_select_db($dbname))
    die("Can't select database");

// sending query
$result = mysql_query("SELECT teams.Team, teams.poule , Sum(t.scores) AS Score, Sum(t.Goalsaldo) AS GoalSaldo, Sum(t.Goals) AS Goals
FROM teams INNER JOIN (
   SELECT games.Team1 as Team,  If(PuntTeam1>PuntTeam2,3,If(PuntTeam1=PuntTeam2 AND EndTime>0,1,0)) AS scores, cast(PuntTeam1 as signed)-cast(PuntTeam2 as signed) AS Goalsaldo, games.PuntTeam1 AS Goals
    from  games
    union all
   SELECT games.Team2 as Team,  If(PuntTeam2>PuntTeam1,3,If(PuntTeam1=PuntTeam2 AND EndTime>0,1,0)) AS scores, cast(PuntTeam2 as signed)-cast(PuntTeam1 as  signed) AS Goalsaldo, games.PuntTeam2 AS Goals
    from games
)  AS t ON teams.Id = t.Team
GROUP BY teams.Team, t.Team
ORDER BY teams.poule ASC, Sum(t.scores) DESC , Sum(t.Goalsaldo) DESC , Sum(t.Goals) DESC");
if (!$result) {
    die("Query to show fields from table failed");
}

$fields_num = mysql_num_fields($result);


echo "<h1><font color=white>Tussenstand: </h1>";
echo "<table border='1'><tr>";
echo '<meta http-equiv="refresh" content="10">';
// printing table headers
for($i=0; $i<$fields_num; $i++)
{
    $field = mysql_fetch_field($result);
    echo "<td><font color=white>{$field->name}</td>";
}
echo "</tr>\n";
// printing table rows
while($row = mysql_fetch_row($result))
{
    echo "<tr>";

    // $row is array... foreach( .. ) puts every element
    // of $row to $cell variable
    foreach($row as $cell)
        echo "<td><font color=white>$cell</td>";

    echo "</tr>\n";
}
mysql_free_result($result);
?>
