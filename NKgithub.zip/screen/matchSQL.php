<?php
$servername = "localhost";
$username = "USER1";
$password = "NKtest";
$dbname = "MATCHES";

  $tableName1 = "games";
  $tableName2 = "CurrentGame";
  $tableName3 = "teams";

  //--------------------------------------------------------------------------
  // 1) Connect to mysql database
  //--------------------------------------------------------------------------
  $con = mysql_connect($servername, $username, $password);
  $dbs = mysql_select_db($dbname, $con);

  //--------------------------------------------------------------------------
  // 2) Query database for data minute(games.StartTime), second(StartTime)
  //--------------------------------------------------------------------------
  //$result1 = mysql_query("SELECT teams.Team, Tabel1_1.Team, games.PuntTeam1, games.PuntTeam2, games.ID, (if(games.EndTime='0' and games.StartTime>'0', hour(now())*3600+minute(now())*60+second(now())-games.StartTime,(if(games.StartTime='0', '0','0')))) AS `Timer` FROM CurrentGame INNER JOIN ((teams RIGHT JOIN games ON teams.ID =games.Team1) LEFT JOIN teams AS Tabel1_1 ON games.Team2 = Tabel1_1.ID) ON CurrentGame.gameID = games.Id GROUP BY teams.Team, Tabel1_1.Team, games.Team1, games.Team2, games. PuntTeam1, games. PuntTeam2" );          //query
  $result1 = mysql_query("SELECT teams.Team, Tabel1_1.Team, games.PuntTeam1, games.PuntTeam2, games.ID, TIME_FORMAT(SEC_TO_TIME(if(games.EndTime='0' and games.StartTime>'0', hour(now())*3600+minute(now())*60+second(now())-games.StartTime,(if(games.StartTime='0', '0',games.EndTime-games.StartTime)))),'%i:%s') AS `Timer` FROM CurrentGame INNER JOIN ((teams RIGHT JOIN games ON teams.ID =games.Team1) LEFT JOIN teams AS Tabel1_1 ON games.Team2 = Tabel1_1.ID) ON CurrentGame.gameID = games.Id GROUP BY teams.Team, Tabel1_1.Team, games.Team1, games.Team2, games. PuntTeam1, games. PuntTeam2" );          //query


  $array1 = mysql_fetch_row($result1);
  // 3) echo result as json

  echo json_encode($array1);

?>

