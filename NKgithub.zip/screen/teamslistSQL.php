<?php
$servername = "localhost";
$username = "USER1";
$password = "NKtest";
$dbname = "MATCHES";


if (!mysql_connect($servername, $username, $password))
    die("Can't connect to database");

if (!mysql_select_db($dbname))
    die("Can't select database");

// sending query
$result = mysql_query("SELECT team, Poule from teams order by id");

if (!$result) {
    die("Query to show fields from table failed");
}

$fields_num = mysql_num_fields($result);


echo "<h1><font color=white>Ingeschreven teams:</h1>";
echo "<table border='1'><tr>";
echo '<meta http-equiv="refresh" content="300">';
// printing table headers
for($i=0; $i<$fields_num; $i++)
{
    $field = mysql_fetch_field($result);
    echo "<td><font color=white>{$field->name}</td>";
}
echo "</tr>\n";
// printing table rows
while($row = mysql_fetch_row($result))
{
    echo "<tr>";

    // $row is array... foreach( .. ) puts every element
    // of $row to $cell variable
    foreach($row as $cell)
        echo "<td><font color=white>$cell</td>";

    echo "</tr>\n";
}
mysql_free_result($result);
?>
