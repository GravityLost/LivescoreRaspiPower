<?php
$mysqli = new mysqli("localhost", "USER1", "NKtest", "MATCHES");
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}


$mysqli->query("UPDATE games set games.StartTime=hour(now())*3600+minute(now())*60+second(now()) WHERE games.ID = (SELECT max( CurrentGame.GameID) FROM CurrentGame)")

?>